/*=== === === ===
Created by Paradise1337
Design by Paradise
===	===	===	===*/

ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "MultiButton"
ENT.Author = "Paradise"
ENT.Spawnable = true
ENT.Category = "DarkRP"
ENT.AdminSpawnable = false

function ENT:SetupDataTables()
	self:NetworkVar("String",0,"Data")
end